
# remove everything from the user environment ----------------------------------
rm(list = ls())
gc()

# load packages ----------------------------------------------------------------

pkg <- c(
  "assertr",
  "broom",
  "dplyr",
  "forcats",
  "ggplot2",
  "ggstance",
  "janitor",
  "knitr",
  "kableExtra",
  "metafor",
  "patchwork",
  "readr",
  "readxl",
  "rvest",
  "scales",
  "stringr",
  "tidyr"
)

for (p in pkg) {
  suppressMessages(
    suppressPackageStartupMessages(
      library(p, character.only = TRUE)
    )
  )
}

rm(pkg, p)

# set options ------------------------------------------------------------------

options(
  readr.show_col_types = FALSE,
  dplyr.summarise.inform = FALSE
)

# results folder ---------------------------------------------------------------

results_dir <- function(...) {
  dir.create("ma results", showWarnings = FALSE, recursive = TRUE)
  paste0("ma results/", ...)
}
