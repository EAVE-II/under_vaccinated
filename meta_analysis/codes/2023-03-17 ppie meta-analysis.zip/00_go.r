
setwd("~/Projects/DCP08 - NCSi2 vacc breakthrough/2023-03-17 ppie meta-analysis")

source("clear_workspace.r")

source("01_pool_descriptives.r")

source("02_meta_analyse_main.r")

source("03_meta_analyse_conditions.r")
