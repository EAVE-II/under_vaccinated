source("clear_workspace.r")

# look up table for clean xvar and xlbl names ----

lkp_xvar_xlbl <- read_xlsx(path = "lkp_xvar_xlbl.xlsx")

# load Wales ---

d_wales_overall <-
  read_csv(file = "nation results/wales 2023-02-23/m_hosp_death_overall_coef_adj.csv") %>% 
  mutate(vaccine = "overall")

d_wales_md <-
  read_csv(file = "nation results/wales 2023-02-23/m_hosp_death_md_coef_adj.csv") %>% 
  mutate(vaccine = "md")

d_wales_pb <-
  read_csv(file = "nation results/wales 2023-02-23/m_hosp_death_pb_coef_adj.csv") %>% 
  mutate(vaccine = "pb")

d_wales <-
  bind_rows(
    d_wales_overall,
    d_wales_md,
    d_wales_pb
  ) %>% 
  mutate(
    country = factor("wales"),
    vaccine = fct_inorder(vaccine)
  ) %>% 
  left_join(
    y = lkp_xvar_xlbl,
    by = join_by(xvar == wales_xvar, xlbl == wales_xlbl)
  ) %>% 
  select(
    country,
    vaccine,
    xvar = clean_xvar,
    xlbl = clean_xlbl,
    estimate,
    std.error
  ) %>% 
  assert(not_na, xvar, estimate)

rm(d_wales_overall, d_wales_md, d_wales_pb)

# load Scotland ----

d_scotland <-
  read_xlsx(
    path = "nation results/scotland 2023-03-17/Table 2 cox analysis results 17032023.xlsx",
    skip = 1,
    .name_repair = make_clean_names
  ) %>% 
  mutate(
    country = factor("scotland"),
  ) %>% 
  select(
    country,
    xvar            = variable,
    xlbl            = category,
    overall_hr      = odds_ratio,
    overall_ci_low  = ci_low,
    overall_ci_high = ci_high,
    md_hr           = odds_ratio_2,
    md_ci_low       = ci_low_2,
    md_ci_high      = ci_high_2,
    pb_hr           = odds_ratio_3,
    pb_ci_low       = ci_low_3,
    pb_ci_high      = ci_high_3
  ) %>% 
  # make long by (subset) analysis
  pivot_longer(
    cols = matches("_(hr|ci)"),
    names_to = c("vaccine", "model_param"),
    names_pattern = "(overall|md|pb)_(.+)"
  ) %>% 
  pivot_wider(
    names_from = "model_param"
  ) %>% 
  mutate(vaccine = fct_inorder(vaccine)) %>% 
  arrange(vaccine) %>% 
  # remove reference rows
  filter(!(
    hr == 1 &
    ci_low == 1 &
    ci_high == 1
  )) %>% 
  # get original estimate and standard error
  mutate(
    estimate = log(hr),
    # ci_low = exp(estimate - 1.96 * se)
    # se = (log(ci_low) - estimate) / -1.96
    std.error = (log(ci_low) - log(hr)) / -1.96
  ) %>% 
  # clean variable and level names
  left_join(
    y = lkp_xvar_xlbl,
    by = join_by(xvar == scotland_xvar, xlbl == scotland_xlbl)
  ) %>% 
  # final select
  select(
    country,
    vaccine,
    xvar = clean_xvar,
    xlbl = clean_xlbl,
    estimate,
    std.error
  ) %>% 
  assert(not_na, xvar, estimate)

# combine coefs from all nations ----

d_all <- 
  bind_rows(
    d_scotland,
    d_wales
  ) %>% 
  mutate(
    xvar = factor(xvar, unique(lkp_xvar_xlbl$clean_xvar)),
    xlbl = factor(xlbl, unique(lkp_xvar_xlbl$clean_xlbl))
  ) %>% 
  arrange(
    country,
    vaccine,
    xvar,
    xlbl
  )

# visually inspect ----

d_all %>% 
pivot_wider(
  names_from = country,
  values_from = c(estimate, std.error),
  names_glue = "{country}_{.value}"
) %>% 
arrange(
  vaccine,
  xvar,
  xlbl
) %>% 
kable(
  digits = 2
) %>% 
kable_styling(
  bootstrap = c("striped", "condensed"),
  full_width = FALSE
) %>% 
print()

# fixed-effect meta-analyses ----

extract_ma_coef <- function(x) {
  nm <- deparse(substitute(x))
  nm <- str_replace(nm, "ma_fit_", "")
  
  d <-
    coef(summary(x)) %>% 
    as_tibble(rownames = "coef") %>% 
    separate(
      col = coef,
      into = c("xvar", "xlbl"),
      sep = ":"
    ) %>% 
    mutate(
      country = "meta",
      country = factor(country),
      vaccine = factor(nm),
      xvar = str_replace(xvar, "xvar", ""),
      xvar = factor(xvar, unique(lkp_xvar_xlbl$clean_xvar)),
      xlbl = str_replace(xlbl, "xlbl", ""),
      xlbl = factor(xlbl, unique(lkp_xvar_xlbl$clean_xlbl))
    ) %>% 
    select(
      country,
      vaccine,
      xvar,
      xlbl,
      estimate,
      std.error = se
    )
  
  return(d)
}

mg_fit_overall <- metagen(
  TE = estimate,
  seTE = std.error,
  studlab = country,
  data = d_all,
  subgroup = xlbl,
  subset = (vaccine == "overall" & xvar == "dose"),
  sm = "HR",
  fixed = TRUE,
  random = TRUE,
  method.tau = "REML",
  hakn = FALSE,
  backtransf = FALSE
)

ma_fit_overall <- rma(
  yi = estimate,
  sei = std.error,
  data = d_all,
  subset = (vaccine == "overall" & xvar == "dose" & xlbl == "4-5 weeks"),
  method = "FE"
)

?meta::forest(mg_fit_overall)
ma_fit_overall

ma_fit_md <- rma(
  yi = estimate,
  sei = std.error,
  mods = ~ -1 + xvar:xlbl,
  data = d_all,
  subset = (vaccine == "md"),
  method = "FE" # fixed effect
)

ma_fit_pb <- rma(
  yi = estimate,
  sei = std.error,
  mods = ~ -1 + xvar:xlbl,
  data = d_all,
  subset = (vaccine == "pb"),
  method = "FE" # fixed effect
)

stop("HERE")

d_all <-
  bind_rows(
    d_all,
    extract_ma_coef(ma_fit_overall),
    extract_ma_coef(ma_fit_md),
    extract_ma_coef(ma_fit_pb)
  )

# roll my own forest plot ----

lkp_country <- c(
  "meta"             = "#4daf4a",
  "england"          = "#984ea3",
  "scotland"         = "#377eb8",
  "wales"            = "#e41a1c",
  "northern ireland" = "#ff7f00",
  "ref"              = "#000000"
)

lkp_pretty_xvar <- c(
  "Time since\nAutumn 2022 booster"   = "dose",
  "Previous\nvaccination"             = "vacc_prv",
  "Non-COVID hospital\nadmission"     = "hosp_other",
  "Sex"                               = "sex",
  "Age"                               = "age",
  "BMI"                               = "bmi",
  "Number of clinical\nrisk groups"   = "risk_group_n",
  "Household size"                    = "household_n",
  "Area deprivation\nquintile"        = "area_deprivation",
  "Urban/rural area"                  = "urban_rural"
)

d_ref <-
  lkp_xvar_xlbl %>% 
  filter(is_reference == 1) %>% 
  mutate(
    country = factor("ref"),
    xvar = fct_inorder(clean_xvar),
    xlbl = fct_inorder(clean_xlbl),
    estimate = 0,
    std.error = 0
  ) %>% 
  select(
    country,
    xvar,
    xlbl,
    estimate,
    std.error
  ) %>% 
  cross_join(data.frame(vaccine = factor(c("overall", "md", "pb"))))

p_forest <-
  bind_rows(d_all, d_ref) %>% 
  mutate(
    xvar = factor(xvar, lkp_pretty_xvar, names(lkp_pretty_xvar)), 
    country = factor(country, names(lkp_country)),
    hr = exp(estimate),
    hr.lower = exp(estimate - 1.96 * std.error),
    hr.upper = exp(estimate + 1.96 * std.error)
  ) %>% 
  ggplot(aes(
    x = hr,
    xmin = hr.lower,
    xmax = hr.upper,
    y = xlbl,
    colour = fct_rev(country)
  )) +
  facet_grid(
    rows = vars(xvar),
    cols = vars(vaccine),
    space = "free_y",
    scales = "free_y",
    switch = "y"
  ) +
  geom_vline(
    xintercept = 1,
    colour = "#000000",
    linetype = 1
  ) +
  geom_pointrange(
    position = position_dodge(0.5)
  ) +
  scale_x_continuous(
    name = "Hazards ratio",
    breaks = pretty_breaks()
  ) +
  scale_colour_manual(
    values = lkp_country,
    guide = guide_legend(reverse = TRUE)
  ) +
  coord_cartesian(
    xlim = c(0, 20)
  ) +
  theme_grey(base_size = 12) +
  theme(
    axis.title.y = element_blank(),
    legend.title = element_blank(),
    legend.position = "top",
    panel.grid.minor = element_blank(),
    strip.placement = "outside",
    strip.background.y = element_blank(),
    strip.text.y.left = element_text(angle= 0, face = "bold")
  )

print(p_forest)

ggsave(
  p_forest,
  file = "p_main_nation_meta_hr.png",
  width = 13,
  height = 10
)
